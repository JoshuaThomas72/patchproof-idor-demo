"""PatchProof scanner package."""
